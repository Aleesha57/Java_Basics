package StringBffer;
import java.util.*;
import java.io.*;
public class StrBf {
	public static void main(String[] args) {
		
		StringBuffer Sb=new StringBuffer();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter");
		Sb.append(sc.nextLine());
		System.out.println("String:"+Sb);
		String s="5";
		String d="2";
		int i=Integer.parseInt(s);
		int g=Integer.parseInt(d);
		System.out.println("String:"+(i+g));
	}
}
