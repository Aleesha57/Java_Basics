package StringBffer;
import Package.Calcu;
public class Sum1 {
public static void main(String[] args) {
	Calcu ch=new Calcu();
	int s=ch.add(2, 2);
	System.out.println("the sum is:"+s);
	}

}
