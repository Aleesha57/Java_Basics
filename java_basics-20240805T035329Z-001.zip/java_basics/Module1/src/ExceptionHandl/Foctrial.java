package ExceptionHandl;
import java.io.*;
class rfact{
	public int facto(int n) {
		if(n>=1) 
			return(n*facto(n-1));
		
		else return 1;
		
	}
}
public class Foctrial {
	public static void main(String[] args) {
		try {
			rfact fo=new rfact();
			
			DataInputStream dis=new DataInputStream(System.in);
			String n=dis.readLine();
			int i=Integer.parseInt(n);
			int h=fo.facto(i);
			System.out.println(h);
			
		}catch(Exception e) {
			System.out.println(e);
		}
		
		
	}

}
