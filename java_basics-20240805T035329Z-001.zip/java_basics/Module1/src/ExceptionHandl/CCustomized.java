package ExceptionHandl;

public class CCustomized {
	public static void main(String[] args) {
		float f=5;
		float y=100;
		try {
			float x=f/y;
			if(x<1) 
				throw new AliException("too small value");
			
		}catch(AliException e) {
			System.out.println("catch ali exception");
			System.out.println(e);
		}
	}

}

class AliException extends Exception{
	AliException(String mess){
		super(mess);
	}
}