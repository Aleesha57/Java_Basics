package ExceptionHandl;

import java.rmi.AccessException;

public class NestedTry {

	public static void main(String[] args) {
		try {
			
			try {
				int i=20/0;
				try {
					int ar[]= {2,6,9,8,5};
					System.out.println("arr is"+ar[10]);
				}catch(ArithmeticException e) {
					System.out.println("er 1:"+e);
				}
				
			}catch(ArithmeticException e) {
				System.out.println("er 2:"+e);
			}
			
		}catch(ArithmeticException e) {
			System.out.println("er 3:"+e);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("er 4:"+e);
		}
	}
}
