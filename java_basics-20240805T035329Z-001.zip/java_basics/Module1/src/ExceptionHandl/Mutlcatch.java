package ExceptionHandl;

public class Mutlcatch {
	public static void main(String[] args) {
		try {
			int a[]=new int[5];
			int y= a[1]=3;
			 int x=y/0;
			 
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("error 1:"+e);		}
		catch(ArithmeticException ee) {
			System.out.println("error 2:"+ee);
		}
		catch(NullPointerException e) {
			System.out.println("error 3:"+e);
	}

}
}
