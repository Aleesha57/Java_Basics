package ExceptionHandl;



public class tryCtch {
	static void age(int a) throws Exception {
		if (a<18) {
			throw new ArrayIndexOutOfBoundsException("age is <18");
		}
	}
	public static void main(String[] args) throws Exception {
		try {
			int a[]=new int[2];	
			a[1]=25;
			age(12);
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}
		finally {
			System.out.println("Finnaly excecuted");
		}
	}

}
