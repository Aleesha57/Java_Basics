package ProducrConsmer;


public class PCprob {
	private int counter=0;
	public void Increment() {
		synchronized(this) {
			counter++;
		}
	}
	public int getCount() {
		synchronized(this) {
			return counter;
		}
	}
	public static void main(String[] args) {
		PCprob c=new PCprob();
	Thread t1=new Thread(()->{
	for(int i=0;i<1000;i++) {
		c.Increment();
	}
	});
	Thread t2=new Thread(()->{
		for(int i=0;i<1000;i++) {
			c.getCount();
		}
		});
	t1.start();
	t2.start();
	try {
		t1.join();
		t2.join();
	}catch(InterruptedException e) {
		
	}
	System.out.println("count"+c.getCount());
	}

}
