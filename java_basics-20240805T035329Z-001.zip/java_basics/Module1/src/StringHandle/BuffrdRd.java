package StringHandle;
import java.util.*;
import java.io.*;
public class BuffrdRd {
	public static void main(String[] args)throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Scanner sc =new Scanner(System.in);
		System.out.println("enter String:");
		String sh=br.readLine();
		
		System.out.println("enter String:");
		String s=sc.nextLine();
		System.out.println("1st name:"+s);
		System.out.println("2nd name:"+sh);
	}

}
