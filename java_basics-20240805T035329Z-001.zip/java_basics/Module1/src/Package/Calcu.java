package Package;

public class Calcu {
	protected int add(int a,int b) { ///public ,defaut,protected(StringBffer)
		return(a+b);
		
	}

}
