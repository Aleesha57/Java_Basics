package Package;
import Package.Calcu.*;
public class Sum1 {
public static void main(String[] args) {
	Calcu c=new Calcu();
	int s=c.add(2, 2);
	System.out.println("the sum is:"+s);
	}

}
