package jdbc;
import java.sql.*;

public class jdbc1 {
	
	public static void main(String[] args) {
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","ali");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from Orders");
//			while(rs.next())
//			{
//				System.out.println(rs.getString(1));
//				System.out.println(rs.getString(4));
//			}
			ResultSetMetaData md=rs.getMetaData();
			System.out.println("column count is:"+md.getColumnCount());
			System.out.println("column name is:"+md.getColumnName(1));
			System.out.println("column count is:"+md.getColumnTypeName(2));
			System.out.println("column count is:"+md.getTableName(1));
			con.close();
			
		}catch(Exception e) {
			System.out.println(e);
		}
		
		
	}

}
