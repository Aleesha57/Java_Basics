package AWT;

import java.awt.*;

public class AssoFrame {
	AssoFrame(){
		
		Frame f=new Frame("my java frame");
		f.setSize(500,500); //width,height
		f.setVisible(true);//by default false
		f.setBackground(Color.blue);
		f.setForeground(Color.black);
		Image i=Toolkit.getDefaultToolkit().getImage("G:\\desktop backup\\photos\\alisha\\trip pics\1630925578965");
		f.setIconImage(i);
		
		//button
		Button b = new Button("Login");
		b.setBounds(100,250,80,30);
		f.add(b);
		Label l = new Label("Name");
		l.setBounds(5,100,80,30);
		f.add(l);
		
		TextField t = new TextField();
		t.setBounds(200,100,80,30);
		f.add(t);
		
		
	}
	
	public static void main(String[] args) {
		AssoFrame f =new AssoFrame();
		
	}

}
