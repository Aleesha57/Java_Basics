package AWT;
import java.awt.*;
import java.awt.event.*;
public class PanelDemo implements WindowListener{
	PanelDemo(){
		Frame f= new Frame("my Panel"); 
		Panel p=new Panel();
		p.setBounds(50,80,200,200);
		p.setBackground(Color.red);
		
		Button b1=new Button("B1");
		b1.setBounds(100,100,80,50);
		b1.setBackground(Color.blue);
		f.add(b1);
		Button b2 =new Button("B2");
		b2.setBounds(100,150,80,50);
		b2.setBackground(Color.blue);
		f.add(b2);
		p.add(b1);
		p.add(b2);
		f.add(p);
		f.addWindowListener(this);
		
		f.setSize(400,400);
		f.setLayout(null);
		f.setVisible(true);
		
	}
	public void windowClosing(WindowEvent we) {
		System.exit(0);
	}
	public static void main(String[] args) {
		PanelDemo f =new PanelDemo();
	}

}
