package AWT;
import java.awt.*;
import java.awt.event.*;
public class CheckboxGrp implements WindowListener {
	CheckboxGrp(){
		Frame f=new Frame("my checkboxGroup");
		CheckboxGroup cbg=new CheckboxGroup();
		Checkbox cb1 =new Checkbox("JAVA",cbg,true);
		cb1.setBounds(100,100,60,50);
		Checkbox cb2 =new Checkbox("CG",cbg,false);
		cb2.setBounds(100,150,60,50);
		Checkbox cb3 =new Checkbox("SS",cbg,false);
		cb3.setBounds(100,200,60,50); 
		f.add(cb1);
		f.add(cb2);
		f.add(cb3);
		f.setSize(400,400);
		f.setLayout(null);
		f.setVisible(true);
		f.addWindowListener(this);
		
		
	}
	public void windowClosing(WindowEvent we) {
		System.exit(0);
	}
public static void main(String[] args) {
	CheckboxGrp f=new CheckboxGrp();
}
}
