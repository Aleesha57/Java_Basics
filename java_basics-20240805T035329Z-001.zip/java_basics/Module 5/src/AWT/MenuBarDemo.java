package AWT;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
public class MenuBarDemo implements ActionListener,WindowListener {
	Label l1,l2;Frame f;
	MenuBarDemo(){
		 f=new Frame("my menuBar");
		MenuBar mb=new MenuBar();
		Menu m1=new Menu("File");
		Menu m2=new Menu("Edit");
		Menu m3=new Menu("Source");
		mb.add(m1);
		mb.add(m2);
		mb.add(m3);
		MenuItem i1=new MenuItem("Item 1");
		MenuItem i2=new MenuItem("Item 2");
		MenuItem i3=new MenuItem("Item 3");
		MenuItem i4=new MenuItem("Item 4");
		
		l1=new Label();
		l1.setBounds(50,200,200,100);
		f.add(l1);
		l2=new Label();
		l2.setBounds(50,300,200,100);
		f.add(l2);
		m1.add(i4);
		m1.add(i3);       
		m2.add(i1);
		m3.add(i2);      
		f.setMenuBar(mb);
		f.setSize(400,400);
		f.setLayout(null);
		f.setVisible(true);
		i3.addActionListener(this);
		f.addWindowListener(this);
	}
	
	public static void main(String[] args) {
		MenuBarDemo f =new MenuBarDemo();
	}
	@Override
	public void windowClosing(WindowEvent e) {
		System.exit(0);
		
	}
	public void actionPerformed(ActionEvent ee) {
		FileDialog fd=new FileDialog(f,"openfile",FileDialog.LOAD);
		fd.setVisible(true);
		String dir=fd.getDirectory();
		l1.setText(dir);
		String f=fd.getFile();
		l2.setText(f);
		}
	
}
