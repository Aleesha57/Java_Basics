package AWT;
import java.awt.*;
import java.awt.event.*;

public class EventDemo implements ActionListener, WindowListener {
	TextField t,t1;Button b1,b2;Label l;
	EventDemo(){
		Frame f = new Frame("my event demo");
		f.setSize(400,400);
		f.setLayout(null);
		f.setVisible(true);
		 b1 = new Button("Button1");
		b1.setBounds(200,300,90,30);
		f.add(b1);
		 b2 = new Button("Button2");
		b2.setBounds(200,270,90,30);
		f.add(b2);

		l =new Label("");
		l.setBounds(10,100,100,30);
		f.add(l);
		t=new TextField();
		t.setBounds(100,200,100,30);
		f.add(t);
	    t1=new TextField();
		t1.setBounds(100,250,100,30);
		f.add(t1);
		f.addWindowListener(this);  //registering litsener
		b1.addActionListener(this);
		b2.addActionListener(this);
		
	}
	
	public void windowClosing(WindowEvent we) {//window action
		System.exit(0); //event handling
	}
	
	public void actionPerformed(ActionEvent asd) {//button action
		//t.setText("Good click");
		if(asd.getSource()==b1) {
			l.setText("B1 clicked");
		
		}
		else {
		
			String txt = t.getText();
			t.setText("Count is"+ txt.length());}
		
	}
	public static void main(String[] args){
		EventDemo f=new EventDemo();
		
	}

}
