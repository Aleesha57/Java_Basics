package AWT;
import java.awt.*;
import java.awt.event.*;
public class ChoiceDemo implements ActionListener,WindowListener {
	TextField t1;Button b1;Choice c1;
	ChoiceDemo(){
		Frame f=new Frame();
	 c1=new Choice();
		c1.setBounds(100, 100, 75, 75);
	
		f.add(c1);
		c1.add("Java");
		c1.add("Cg");
		c1.add("MM");
		c1.add("SS");
		c1.add("Ja");
		c1.add("Cp");
		c1.add("Mg");
		c1.add("Ssd");
		t1=new TextField();
		t1.setBounds(50,200,80,30);
		f.add(t1);
		b1 =new Button("click");
		b1.setBounds(30,300,80,30);
		f.add(b1);
		
		f.setSize(400,400);
		f.setLayout(null);
		f.setVisible(true);
		
		f.addWindowListener(this);
		b1.addActionListener(this);
	}
	public void windowClosing(WindowEvent we) {
		System.exit(0);
	}
	public void actionPerformed(ActionEvent e) {
			
			String data=c1.getItem(c1.getSelectedIndex());
			t1.setText(data);
	}
	public static void main(String[] args) {
		ChoiceDemo f =new ChoiceDemo();
	}

}
