package AWT;
import java.awt.*;

public class InhFrame extends Frame {
	InhFrame(){
		setSize(400,400);
		setVisible(true);
		
	}


public static void main(String[] args) {
	InhFrame f=new InhFrame();
	
}
}
