package awtLayouts;

import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class gridLayDemo implements WindowListener {
	  Button buttons[];
	gridLayDemo(){
		Frame f= new Frame();
		buttons=new Button[15];
		for(int i=1;i<15;i++) {
			buttons[i]=new Button("B"+(i));
			f.add(buttons[i]);
			}
		f.setLayout(new GridLayout(3,4));
		f.setSize(300,300);
		f.setVisible(true);

		f.addWindowListener(this);
	}
	public void windowClosing(WindowEvent we) {
		System.exit(0);
	}
	public static void main(String[] args) {
		new gridLayDemo();
		
	}
}
