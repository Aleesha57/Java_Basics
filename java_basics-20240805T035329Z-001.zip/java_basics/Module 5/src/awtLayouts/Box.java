package awtLayouts;

public class Box {

}
