package awtLayouts;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
public class BrorderLayoutDemo implements WindowListener{
	//Button b[];
	BrorderLayoutDemo(){
	Frame f= new Frame();
//		b=new Button[5];
//		for(int i=1;i<=5;i++) {
//			b[i]=new Button("B"+i);
//			
//		}
		Button b1=new Button("B1");
		b1.setBounds(100,100,80,50);
		b1.setBackground(Color.blue);
		f.add(b1);
		Button b2 =new Button("B2");
		b2.setBounds(100,150,80,50);
		b2.setBackground(Color.blue);
		Button b3=new Button("B1");
		b3.setBounds(100,100,80,50);
		b3.setBackground(Color.blue);
		f.add(b3);
		Button b4 =new Button("B2");
		b4.setBounds(100,150,80,50);
		b4.setBackground(Color.blue);
		f.add(b4);
		Button b5=new Button("B1");
		b5.setBounds(100,100,80,50);
		b5.setBackground(Color.blue);
		f.add(b5);
		f.add(b2);
		f.add(b1,BorderLayout.NORTH);
		f.add(b2,BorderLayout.SOUTH);
		f.add(b3,BorderLayout.EAST);
		f.add(b4,BorderLayout.CENTER);
		f.add(b5,BorderLayout.WEST);
		f.setSize(400,400);
		f.setVisible(true);  
		f.addWindowListener(this);
	}
	public void windowClosing(WindowEvent we) {
		System.exit(0);
	}
	public static void main(String[] args) {
		BrorderLayoutDemo bl=new BrorderLayoutDemo();
	}

}
