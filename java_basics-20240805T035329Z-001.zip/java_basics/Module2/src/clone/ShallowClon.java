package clone;
//something went wrong
class Test{
	int a,b;
	public Object clone() {
		try {
			
			return super.clone();
		}catch(Exception e) {
			System.out.println(e);
		}
		return this;
	}
}
public class ShallowClon {


	public static void main(String[] args) {
		Test t1=new Test();
		t1.a=10;
		t1.b=20;
		System.out.println("elements are "+t1.a+"and"+t1.b);
		Test t2 = (Test)t1.clone();
		
	}
}
