package covariantRtnTyp;

class A{
	public A Sleep() {
		
		System.out.println("AAAA");
		return(this);
	}
}
class B{
	public B run() {
		System.out.println("BBB");
		return(this);
	}
}

public class Cov {
	public static void main(String[] args) {
		
		A a=new A();a.Sleep();
		B b=new B();b.run();
	}

}
