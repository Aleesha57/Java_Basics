package Super;
class A{
	int x=20;
	
	
}
class B extends A{
	int x=10;
	void prnt() {
		System.out.println("super"+super.x);
		System.out.println("super"+x);
		
	}
	
	
}

 class SuperKey {
	public static void main(String[] args) {
		B b;
		b=new B();
		b.prnt();
		
	}
	

}
