package Super;

class H{
	String h;
	
	public H(String s) {
		this.h =s;
		System.out.println("H constructor:"+this.h);
		
	}
}
class J extends H{
	int x=200;
	
	public J(String s) {
		
	 super(s);
		
	}

		
	}

public class superConstrctr {
	public static void main(String[] args) {
		J b=new J("ali");

	}

}
