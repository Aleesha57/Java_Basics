package Super;
class M{
	public void display() {
		System.out.println("disp");
	}
}
class K extends M{
	public void display() {
		System.out.println("ali");
	}
	void test() {
		display();
		super.display();
	}
}
public class superMethod {
	public static void main(String[] args) {
		K b=new K();
		b.test();
	}

}
