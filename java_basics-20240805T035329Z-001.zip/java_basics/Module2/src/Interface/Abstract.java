package Interface;

abstract class Animal{
	void AnimalSound() {
		
	}
	
}

public class Abstract extends Animal{
	void AnimalSound() {

		System.out.println("Bow Bow");
	}
	
	
	public static void main(String[] args) {
		
		
		Abstract d=new Abstract();
		d.AnimalSound();
	}

}
