package Interface;
interface Animal1{
	public void AnimalSound();
	public void sleep();
		
	}

 class Dog1 implements Animal1{
	public void AnimalSound() {
		System.out.println("Bow Bow");
	}
	public void sleep() {
		System.out.println("zzzzzz");
	}

}


public class Interfaces {
	public static void main(String[] args) {
	Dog1 d=new Dog1();
	d.AnimalSound();
	d.sleep();
	
}
}
