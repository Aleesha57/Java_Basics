package Interface;
abstract class Shape{
	int r;
	double pi=3.14;
	Shape(int a,double b){
		this.r=a;
		this.pi=b;
	}
	abstract double area();
}
class Circl extends Shape{
	Circl(int f,double h){
		super(f,h);
	}
	double area() {
		return (double) (pi*r*r);
	}
	
}
public class Interface2 {
	public static void main(String[] args) {
		Circl c=new Circl(2, 3.14);
		double ar=c.area();
		System.out.println("area:"+ar);
	}
	

}
