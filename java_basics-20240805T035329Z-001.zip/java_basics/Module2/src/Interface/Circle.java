package Interface;
interface Ali{
	void shape();
	void area();
}
class circ implements Ali{
	public void shape() {
		System.out.println("shape is circle");
	}
	public void area() {
		int r=5;
		double area=2*3.14*r*r;
		System.out.println("area of circle:"+area);
	}
}
class rect implements Ali{
	public void shape() {
		System.out.println("shape is rectangle");
	}
	public void area() {
		int h=5;
		int b=4;
		double area=(1/2)*b*h;
		System.out.println("area of rectangle:"+area);
	}
}

public class Circle  {
	public static void main(String[] args) {
		circ c=new circ();
		c.shape();
		c.area();
		
		rect r=new rect();
		r.shape();
		r.area();
		
	}

}
