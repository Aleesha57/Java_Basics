package Interface;
interface shpe{
	double area();
	final double pi=3.14;
}
class cir implements shpe{
	public double area() {
		double r=2.2;
		return(pi*r*r);
	}
	
}

public class Interface3 {
	public static void main(String[] args) {
		cir c =new cir();
		double ar=(double)c.area();
		System.out.println("area:"+ar);
	}

}
