package TypeCasting;
import java.io.*;
public class AreaCircle {
	public static void main(String[] args) {
		float r;
		double area;
		try {
			System.out.println("enter radius");
			DataInputStream dis=new DataInputStream(System.in);
			r=Float.parseFloat(dis.readLine());
			area=3.14*r*r;//widening
			System.out.println("area is:"+area);
		}catch(Exception e) {
			System.out.println(e);
		}
	}

}
