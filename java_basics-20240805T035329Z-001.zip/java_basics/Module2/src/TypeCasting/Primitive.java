package TypeCasting;
//widening-implicit type casting
public class Primitive {
	public static void main(String[] args) {
		int a=1;
		double an=a;
		an=1.5;
		System.out.println(an);
	}

}
