package TypeCasting;
import java.io.*;
public class AreaNarrowing {
	public static void main(String[] args) {
		float r;
		int area;
		try {
			
			System.out.println("enter the radius:");
			DataInputStream dis=new DataInputStream(System.in);
			r=Float.parseFloat(dis.readLine());
			area=(int)(3.14)*(int)r*(int)r;
			System.out.println("area ="+area);

		}catch(Exception e) {
			System.out.println(e);
		}
		
	}

}
