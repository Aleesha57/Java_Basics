package TypeCasting;

public class Explicit {
	public static void main(String[] args) {
		double d=10.25;
		//int df=(int)d;
		int y=2;
		int result=(int)(d/y);
		System.out.println(result);
	}

}
