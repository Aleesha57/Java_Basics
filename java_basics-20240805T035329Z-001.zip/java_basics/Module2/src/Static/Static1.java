package Static;

public class Static1 {
	//ststic member static methods static initialization block
		static int x=10;
		static int y;
		
		static void disp(int a) {
			System.out.println("ali"+x);
			System.out.println("ali"+y);
			System.out.println("ali"+a);
			
		}
		static {
			System.out.println("running");
			y=2;
		}
		public static void main(String[] args) {
			disp(20);
			
		}

	}


