package IniBlock;
class InBlock{
	
	InBlock(){
		System.out.println("Alisha");
	}
	InBlock(int a){
		System.out.println("neha");
	}
	InBlock( int a,double b){
		System.out.println("blaze");
	}
	{
		System.out.println("initialization block");
	}
	public static void main(String[] args) {
		InBlock a= new InBlock();
		new InBlock(10);
		new InBlock(10,5.2);
	}

}
