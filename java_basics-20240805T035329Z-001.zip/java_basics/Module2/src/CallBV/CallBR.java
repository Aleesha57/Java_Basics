package CallBV;
 class CNum{
	public int a;
	
}
class Cswap{
	
	public void swap(CNum p,CNum q) {
		System.out.println("Before swap "+p.a+"and"+q.a);
		int t=p.a;
		p.a=q.a;
		q.a=t;
		System.out.println("after swap "+p.a+"and"+q.a);
	}
}
public class CallBR {
	  public static void main(String[] args) {
		CNum obj=new CNum(); obj.a=5;
		CNum obj2=new CNum();obj2.a=3;
		System.out.println("before swap"+obj.a+"and"+obj2.a);
		System.out.println("\n");
		Cswap obj1=new Cswap();
		obj1.swap(obj,obj2);
		System.out.println("\n");
		System.out.println("before swap"+obj.a+"and"+obj2.a);
		
	}

}
