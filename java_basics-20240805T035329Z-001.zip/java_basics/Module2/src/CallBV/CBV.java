package CallBV;

public class CBV {
	static void Swp(int a,int b) {
		System.out.println("before swaping"+a+"and"+b);
		
		int c=a;
		a=b;
		b=c;
		System.out.println("before swaping"+a+"and"+b);
		
	}
	public static void main(String[] args) {
		int a=20;
		int b=10;
		System.out.println("before swaping"+a+"and"+b);
		Swp(a,b);
		System.out.println("before swaping"+a+"and"+b);
	}

}
