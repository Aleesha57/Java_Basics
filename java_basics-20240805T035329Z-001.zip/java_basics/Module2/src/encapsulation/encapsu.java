package encapsulation;
class Employee{
	private int empNo;
	private String empName;
	public void setempNo(int val){
		empNo=val;
	}
	public void setempName(String sval) {
		empName=sval;
	}
	public int getempNo() {
		return empNo;
	}
	public String getempName() {
		return empName;
	}
}

public class encapsu {
	public static void main(String[] args) {
		Employee obj=new Employee();
		obj.setempNo(203);
		obj.setempName("alisha");
		System.out.println("employee no is:"+obj.getempNo());
		System.out.println("employee name is:"+obj.getempName());
	}

}
