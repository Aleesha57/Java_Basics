package encapsulation;
class emp{
	private int empNo;
	private String empName;
	public void setNo(int val) {
		empNo=val;
		
	}
	public void setName(String sval) {
		empName=sval;
		
	}
	public int getNo() {
		return empNo;
	}
	public String getName() {
		return empName;
	}
}
public class encap1 {
	public static void main(String[] args) {
		emp e=new emp();
		e.setNo(15);
		e.setName("alisha");
		System.out.println("no is:"+e.getNo()+"\nname is:"+e.getName());
		
	}

}
