package Final;

 final class M{
	 void disp() {
		System.out.println("AAAA");
	}
}
class H extends M{//we cant inherit
	void disp() {
		System.out.println("PPPP");
	}
	
}
public class FinalClass {
	public static void main(String[] args) {
		H b=new H();
		b.disp();
		
		
	}

}
