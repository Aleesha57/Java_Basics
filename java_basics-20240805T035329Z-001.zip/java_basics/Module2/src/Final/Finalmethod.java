package Final;

class A{
	final void disp() {
		System.out.println("AAAA");
	}
}
class B extends A{
	void disp() {
		System.out.println("PPPP");
	}
	
}
public class Finalmethod {
	public static void main(String[] args) {
		B b=new B();
		b.disp();
		
		
	}

}
