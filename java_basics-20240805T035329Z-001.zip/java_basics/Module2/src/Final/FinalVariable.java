package Final;

public class FinalVariable{
	public static void main(String[] args) {
		final int i=10;
		final int j;
		j=20;
		j=j+1;
		i=i+1;
		
		System.out.println("AAAA "+j);
		System.out.println("AAAA "+i);
		
	}

}
