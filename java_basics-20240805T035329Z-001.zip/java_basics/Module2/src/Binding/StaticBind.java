package Binding;
class Vehicle{
	public static void Start() {
		
		System.out.println("Vehicle starts");
	}
	}
class car extends Vehicle{
	public static void Start() {
		System.out.println("car starts");
	}
}
public class StaticBind {
	public static void main(String[] args) {
		Vehicle ob1=new car();
		Vehicle ob2=new Vehicle();
		car ob3=new car();
		ob3.Start();
		ob1.Start();
		ob2.Start();
	}

}
