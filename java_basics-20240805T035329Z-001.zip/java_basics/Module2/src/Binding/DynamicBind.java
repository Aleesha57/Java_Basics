package Binding;
class Animal{
	public void Sleep() {
		System.out.println("ZZZZZ");
	}
}//overridden
class Pig extends Animal{
	public void Sleep() {
		System.out.println("HRRRR Hrrrrr");
	}
}
public class DynamicBind {
	public static void main(String[] args) {
		Animal an=new Pig();
		Animal ah=new Animal();
		Pig b=new Pig();
		an.Sleep();
		ah.Sleep();
		b.Sleep();
	}

}
