package Instanceof;

class animal{
	
}
class mammal{
	
}
class reptile{
	
}
class dog{
	
}
public class Instance {
	public static void main(String[] args) {
		
		animal a=new animal();
		mammal m=new mammal();
		reptile r=new reptile();
		dog d=new dog();
		reptile r1=null;
		System.out.println(a instanceof animal);
		System.out.println(m instanceof mammal);
		System.out.println(r instanceof reptile);
		System.out.println(d instanceof dog);
		System.out.println(r1 instanceof reptile);
		//System.out.println(d instanceof animal);//its error
	}

}
