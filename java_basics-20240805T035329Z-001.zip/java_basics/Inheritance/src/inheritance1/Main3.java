package inheritance1;

 class Outer{
	int x=5;
	static class InnerClass{
		int y=10;
	}

}
public class Main3{
	public static void main(String[] args) {
		//OuterClass myOuter =new OuterClass();
     	Outer.InnerClass myInner = new Outer.InnerClass();
		System.out.println(myInner.y);
	}
}
