//polymorphism
package inheritance1;

public class Main1 {
	public static void main(String[] args)
	{
		Animal myanimal=new Animal();
		Animal myDog=new Dog();
		Animal myCat =new Cat();
		myanimal.animalSound();
		myDog.animalSound();
		myCat.animalSound();
	}

}
class Animal {
	protected String ambur ="ali";
	public void animalSound() {
		System.out.println("Animal sound is like");
	}

}
class Cat extends Animal{
	private String name1="Cat";
	public void animalSound() {
		System.out.println("cat bark like meaw");
	
}
}


class Dog extends Animal{
	private String name="dog";
	public void animalSound() {
		System.out.println("Dog bark like bow");
	}
}

