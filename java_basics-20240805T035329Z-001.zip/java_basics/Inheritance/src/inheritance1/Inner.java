package inheritance1;

 public class Inner {
	 public static void main(String[] args) {
		 OuterClass myOuter =new OuterClass();
		 OuterClass.InnerClass myInner =myOuter.new InnerClass();
		 System.out.println(myInner.innerMethod());
	 }
	
}
 class OuterClass{
	 int x=5;
	 class InnerClass{
		 public int innerMethod() {
			 return x;
        }
	 }
 }


