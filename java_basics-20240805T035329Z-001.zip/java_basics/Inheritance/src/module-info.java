/**
 * 
 */
/**
 * 
 */
module Inheritance {
	requires java.desktop;
}