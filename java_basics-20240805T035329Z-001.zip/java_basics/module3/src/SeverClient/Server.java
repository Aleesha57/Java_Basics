package SeverClient;
import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Server{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		try
		{
			ServerSocket ss=new ServerSocket(8888);
			Socket s=ss.accept();
			
			DataInputStream dis =new DataInputStream(s.getInputStream());
			DataOutputStream dos=new DataOutputStream(s.getOutputStream());
			
			dos.writeUTF("you are connected to the server");
			String message=dis.readUTF();
			
			while(!message.equalsIgnoreCase("bye")) {
				message=dis.readUTF();
				System.out.println("Client:"+message);
				sc.next();
				System.out.println("Server :enter a message");
				sc.next();
				String tmp=sc.nextLine();
				dos.writeUTF(tmp);
				
			}
			ss.close();
			s.close();
			dis.close();
			dos.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
}