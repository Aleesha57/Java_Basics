package SeverClient;
import java.io.*;
import java.net.*;
import java.net.ServerSocket; 
import java.util.Scanner;

public class Client{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		try
		{
			Socket socket=new Socket("localhost",8888);
			
			DataInputStream dis =new DataInputStream(socket.getInputStream());
			DataOutputStream dos=new DataOutputStream(socket.getOutputStream());
			String message=dis.readUTF();
			System.out.println("server:"+message);
			while(!message.equalsIgnoreCase("bye")) {
				System.out.println("Client:enter a message");
				String tmp =sc.nextLine();
				dos.writeUTF(tmp);
				message=dis.readUTF();
				System.out.println("Server:"+message);
				
				
				
			}
			socket.close();
			dis.close();
			dos.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
}