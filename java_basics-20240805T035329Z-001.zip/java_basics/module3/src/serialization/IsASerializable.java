package serialization;

import java.io.*;

public class IsASerializable implements  Serializable{
	String name="Aleesha";
	int age =22;
}
