package serialization;
import java.io.*;

public class HasASerialization implements Serializable{
	//engine
	String Model;
	String type;
	int capacity;
	HasASerialization(String model,String type,int capacity){
		this.Model=model;
		this.type=type;
		this.capacity=capacity;
	}
	
	

}
