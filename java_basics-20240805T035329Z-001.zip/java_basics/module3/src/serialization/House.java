package serialization;

import java.io.*;

class Address{

}

public class House implements Serializable {
    double area = 46.7;
    String location;
    String houseName;
    
       public House(double area,String location,String housename) {
    	   
    	  this.area=area;
    	  this.houseName=housename;
    	  this.location=location;
    	   
    	   
    	   
       }
       void info() {
    	   System.out.println("area is :"+this.area);
    	   System.out.println("name is :"+this.houseName);
    	   System.out.println("location is :"+this.location);
       }

    public static void main(String[] args) {
    	
    	House obj =new House(45.89,"ananth","kannur");
    	try
    	{
    		FileOutputStream fout= new FileOutputStream("address.txt");
        	ObjectOutputStream oout =new ObjectOutputStream(fout); 
        	oout.writeObject(obj);
        	fout.close();
        	oout.close();
        	
        	System.out.println("serialization succesfull");
        	FileInputStream fin= new FileInputStream("address.txt");
        	ObjectInputStream oin =new ObjectInputStream(fin);
        	House obj2 =(House) oin.readObject();
        	obj2.info();        	
        	
    	}catch(Exception e) { System.out.println(e);
    	

    }
}
}