package serialization;

//serializible

import java.io.*;

public class Person implements Serializable{

String name;
int salary;
transient String password ="Ali";


Person(String name,int salary){
this.name=name;
this.salary=salary;
}

void info(){
System.out.println("name is :"+this.name);
System.out.println("salary is :"+this.salary);
}

private void passwordInfo(){
System.out.println("password is:"+this.password);
}

public static void main(String[] args){

Person p1= new Person("Alisha",30000);

try{

FileOutputStream fout=new FileOutputStream("Alisha.txt");
ObjectOutputStream oout= new ObjectOutputStream(fout);
oout.writeObject(p1);
fout.close();
oout.close();

System.out.println("serialization is successfull");

FileInputStream fin=new FileInputStream("Alisha.txt");
ObjectInputStream oin= new ObjectInputStream(fin);
Person p2 =(Person) oin.readObject();
System.out.println(p2.password);
p2.passwordInfo();
p2.info();

}catch(Exception e){ System.out.println(e);}
}
}