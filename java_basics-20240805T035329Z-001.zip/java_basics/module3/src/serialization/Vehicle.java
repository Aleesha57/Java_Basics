package serialization;
import java.io.*;

public class Vehicle implements Serializable{
	int wheels =4;
	HasASerialization engine;
	
	public Vehicle(int wheels,HasASerialization engine) {
		this.wheels=wheels;
		this.engine=engine;
	}
	public static void main(String[] args) {
		Vehicle ferrari=new Vehicle(4,new HasASerialization("ABC","Pertrol",467));
		try {
			FileOutputStream fout= new FileOutputStream("vehicle.txt");
			ObjectOutputStream oout=new ObjectOutputStream(fout);
			oout.writeObject(ferrari);
			System.out.println("successfully serialized");
			fout.close();
			oout.close();
		}catch(Exception e) {System.out.println(e);
		}
			
		}
}