package serialization;

import java.io.*;

public class Player extends IsASerializable{
	int score =25;
	public static void main(String[] args) {
		Player obj1= new Player();
		try
		{
			
			FileOutputStream fout=new FileOutputStream("Player.txt");
			ObjectOutputStream oout= new ObjectOutputStream(fout);
			oout.writeObject(obj1);
			fout.close();
			oout.close();
			
			FileInputStream fin=new FileInputStream("Player.txt");
			ObjectInputStream oin= new ObjectInputStream(fin);
			Player obj2 =(Player) oin.readObject();
			System.out.println(obj2.name);
			System.out.println(obj2.age);
			System.out.println(obj2.score);
		}catch(Exception e) { System.out.println(e);
		
	}
}
}
