package datagram;
import java.net.*;
public class DGserver {
	public static void main(String[] args) {
		try {
			
			DatagramSocket ds =new DatagramSocket();
			InetAddress ip =InetAddress.getByName("localhost");
			
			String message="connected";
			DatagramPacket dp =new DatagramPacket(message.getBytes(),message.length(),ip,8888);
			ds.send(dp);
			ds.close();
			
			
			
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}

}
