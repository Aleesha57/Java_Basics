package FileHndlg;

import java.io.File;

public class Filecreate {
	public static void main(String[] args) {
		try {
			File file=new File("E://test.txt");
			if(file.exists()) {
				System.out.println("file exists");
				System.out.println("parent:"+file.getParent());
				System.out.println("path:"+file.getAbsolutePath());
				System.out.println("readable:"+file.canRead());
				System.out.println("can write:"+file.canWrite());
				System.out.println("diroctory or not:"+file.isDirectory());
				System.out.println("file or not:"+file.isFile());
				System.out.println("last modified:"+file.lastModified());
				System.out.println("length:"+file.length());
				
				
			}
			else {
				System.out.println("file does not exists");
			}
//			boolean var=file.createNewFile();
//			if(true) {
//				System.out.println("file created");
//			}
//			else {
//				System.out.println("the file is already created");
//			}
			
		}catch(Exception e) {
			System.out.println(e);
		}
	}

}
