package FileHndlg;

import java.io.DataInputStream;
import java.io.FileOutputStream;

///writing on to a file
public class Filewrite {
	public static void main(String[] args) {
		try {
			
			FileOutputStream fos =new FileOutputStream("E:\\Ali.txt");
			DataInputStream dis=new DataInputStream(System.in);
			String data;
			while(true) {
				System.out.println("enter the data into the file....end with#");
				data=dis.readLine();
				if(data.equals("#")) 
					break;
				fos.write(data.getBytes());
				fos.write("\r\n".getBytes());
				
				
			}
			fos.close();
		}catch(Exception e) {System.out.println(e);
		
		}
	}

}
