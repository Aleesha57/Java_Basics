package jdbcdemo;
import java.sql.*;
public class Parametrized{
	public static void main(String[] args) {
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","ali");
			Statement stmt=con.createStatement();
			Statement stmt1=con.createStatement();
//stmt.executeUpdate("create table Customer(cus_id varchar(20) PRIMARY KEY,cus_name varchar(20),cus_address varchar2(20),cus_ph Int)");
			System.out.println("customer table created");
//			stmt1.executeUpdate("create table order(inv_id varchar(20) PRIMARY KEY,cus_id varchar(20) references Customer(cus_id),inv_date date,total_amnt Int,transaction int)");
//			System.out.println("invoice table created");
			PreparedStatement pst=con.prepareStatement("insert into Users value(?,?,?,?)");//parametrized query
			pst.setString(1,"U008");
			pst.setString(2,"Ali");
			pst.setString(3,"524 ananth");
			pst.setInt(4,255);
			pst.executeUpdate();
			pst.setString(1,"U009");
			pst.setString(2,"blaze");
			pst.setString(3,"524 eedat");
			pst.setInt(4,215);
			pst.executeUpdate();
		}
		catch(Exception e) {System.out.println(e);
		}
		
}
}