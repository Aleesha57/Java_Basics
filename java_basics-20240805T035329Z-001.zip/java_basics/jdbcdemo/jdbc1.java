package jdbcdemo;
import java.sql.*;   /*(before jdbc codes start)*/

public class jdbc1 {
	public static void main(String[] args) {
		try
		{
			//step1 Load the driver class
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//step2: create connection
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","INS30011");
			//step 3: create statement
			Statement stml=con.createStatement();
			//step 4:
			ResultSet rs=stml.executeQuery("select * from stu");
			while(rs.next())
			{
				System.out.println(rs.getString(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getInt(3));
				System.out.println(rs.getInt(4));
				
			}
			con.close();
			
		}
		 catch(Exception e) {System.out.println(e);}
		
	}
 
}
