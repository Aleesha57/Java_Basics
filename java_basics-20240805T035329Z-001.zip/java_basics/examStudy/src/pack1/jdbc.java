package pack1;

import java.sql.*;

public class jdbc {
	public static void main(String[] args) {
		try {
			int i;
			Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "ali");
            Statement st=con.createStatement();
			//st.executeUpdate("create table emple(eno varchar(20),ename varchar(20),esal number,dname varchar(20),dloc varchar(20))");
			System.out.println("table created");
			st.executeUpdate("insert into emple values('101','chetan',10000,'civil','kochi')");
			st.executeUpdate("insert into emple values('102','amish',20000,'accounts','delhi')");
		    System.out.println("eno    chetan   esal   dname   dloc");
			ResultSet rs =st.executeQuery("select * from emple");
			ResultSetMetaData md=rs.getMetaData();
			while(rs.next()) {
				System.out.print(rs.getString(1)+"\t");
				System.out.print(rs.getString(2)+"\t");
				System.out.print(rs.getString(3)+"\t");
				System.out.print(rs.getString(4)+"\t");
				System.out.print(rs.getString(5)+"\t");
				System.out.print("\n");
			}
			System.out.print("\n");
			
//			for(i=1;i<=md.getColumnCount();i++) {
//				System.out.print(md.getColumnName(i)+"\t");
//			}
//			System.out.println("\n");
//			System.out.println("----------------------------------------------------");
//			int rowcnt=0;
//			while(rs.next()) {
//				rowcnt++;
//				for(i=1;i<=md.getColumnCount();i++) {
//					
//					System.out.print(rs.getString(i)+"\t");
//				}
//				System.out.println("\n");
//			}
			con.close();
			}catch(Exception e) {
				System.out.println(e);
			}
		
	}

}
