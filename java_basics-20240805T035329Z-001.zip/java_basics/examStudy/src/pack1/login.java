package pack1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class login {

	private JFrame frame;
	private JTextField t1;
	private JTextField t2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login window = new login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel l1 = new JLabel("name");
		l1.setBounds(54, 62, 46, 14);
		frame.getContentPane().add(l1);
		
		JLabel l2 = new JLabel("pswd");
		l2.setBounds(54, 110, 46, 14);
		frame.getContentPane().add(l2);
		
		t1 = new JTextField();
		t1.setBounds(135, 59, 86, 20);
		frame.getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		t2.setBounds(135, 107, 86, 20);
		frame.getContentPane().add(t2);
		t2.setColumns(10);
		
		JButton b1 = new JButton("login");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "ali");
					PreparedStatement pst=con.prepareStatement("select * from emple where eno=?and ename=?");
					pst.setString(1, t1.getText());
					pst.setString(2, t2.getText());
					ResultSet rs=pst.executeQuery();
					if(rs.next()) {
						System.out.println("exist");
						JOptionPane.showMessageDialog(null,"successfully login");
					}
					else {
						System.out.println("noexist");
						JOptionPane.showMessageDialog(null,"invalid");
					}
					rs.close();
					pst.close();
				}catch(Exception em) {
					System.out.println(em);
				}
				}
		});
		b1.setBounds(200, 185, 89, 23);
		frame.getContentPane().add(b1);
	}
}
