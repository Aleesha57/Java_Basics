package pack1;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowListener;
import java.sql.*;
public  class awt implements ActionListener {
	TextField t1,t2;Label l1,l2,l3;Button b1;
	awt(){
		Frame f=new Frame();
		t1=new TextField();t1.setBounds(200,100, 80, 30);f.add(t1);
		t2=new TextField();t2.setBounds(200,150, 80, 30);f.add(t2);
		l1=new Label("Name");l1.setBounds(20,100, 80, 30);f.add(l1);
		l2=new Label("Password");l2.setBounds(20,150, 80, 30);f.add(l2);
		b1=new Button("login"); b1.setBounds(200,50, 80, 30);f.add(b1);
		l3=new Label();l3.setBounds(20,20, 80, 30);f.add(l3);
		f.setSize(400,400);
		f.setVisible(true);
		f.setLayout(null);
		b1.addActionListener(this);
		f.setBackground(Color.red);
	}
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin@localhost:1521:orcl","system","ali");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from employee");
				String name=t1.getText();
				String pswd=t2.getText();
				while(rs.next()) {
					if((name.equals(rs.getString(1))) &&(pswd.equals(rs.getString(2)))) {
//						
						l3.setText("sucess");
						System.out.println("sucess");break;
					}
					else {
						l3.setText("fail");
						System.out.println("fail");continue;
					}
				}
			} catch (Exception e1) {System.out.println(e);
			
			}
			
		}
	
		public static void main(String[] args) {
			new awt();
		}
	}
	
	


