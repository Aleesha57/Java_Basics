package exam;
import java.io.*;
public class record {
	public static void main(String[] args) {
		int sum=0;
		int innersum=0;
		int i=1;
		int n;
		String  s;
		DataInputStream dis=new DataInputStream(System.in); 
		try{
//			System.out.println("sum");
//			s=dis.readLine();
//			n=Integer.parseInt(s);
//			while(i<=n) {
//				innersum+=i;
//				sum+=innersum;
//				i++;
//				
//			}
//			System.out.println("sum"+sum);
			int reverse=0;
			while(reverse!=0) {
				
			}
		}catch(Exception e) {
			System.out.println(e);
		}
	}

}
