package exam;
import java.io.*;
public class rectangle implements Shape {
	int l;
	int b;
	public rectangle(int l,int b) {
		this.l=l;
		this.b=b;
	}
	public void disp() {
		System.out.println("displaying the rectangle");
	}
	public void calc() {
		double area=(0.5)*l*b;
		System.out.println("area of the rectangle is:"+area);
	}
	
	public static void main(String[] args) {
		System.out.println("1.circle\n2.rectangle");
		DataInputStream dis=new DataInputStream(System.in);
		Shape shape;
		try {
			System.out.println("enter your choice 1 or 2");
			int ch=Integer.parseInt(dis.readLine());
			if(ch==1) {
				System.out.println("enter the radius:");
				int r=Integer.parseInt(dis.readLine());
				shape=new Circle(r);
			}
			else if(ch==2) {
				System.out.println("enter the length:");
				int l=Integer.parseInt(dis.readLine());
				System.out.println("enter the width:");
				int b=Integer.parseInt(dis.readLine());
				shape=new rectangle(l,b);
				
			}
			else {
				System.out.println("invalid....");
				return;
			}
			shape.disp();
			shape.calc();
		}catch(Exception e) {
			System.out.println(e);
		}
	}

}
