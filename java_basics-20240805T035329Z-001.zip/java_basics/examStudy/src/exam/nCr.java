package exam;
import java.io.*;
import pack1.factrial;
public class nCr {
 public static void main(String args[]) {
	 DataInputStream dis =new DataInputStream(System.in);
	 try{
		 System.out.println("enter the value for n:");
		 int n=Integer.parseInt(dis.readLine());
		 System.out.println("enter the value for r:");
		 int r=Integer.parseInt(dis.readLine());
		 double s=factrial.combi(n,r);
		 System.out.println("nCr="+s);
	 }catch(Exception e) {
		 System.out.println(e);
	 }
	 
	 
 }

}
