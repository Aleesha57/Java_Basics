package exam;


public class mthdovr {
	private String name;
	private int age;
	public mthdovr(String name,int age) {
		this.name=name;
		this.age=age;
	}
	
	public void display() {
		System.out.println("name:"+name);
		System.out.println("age:"+age);
		
	}

}

