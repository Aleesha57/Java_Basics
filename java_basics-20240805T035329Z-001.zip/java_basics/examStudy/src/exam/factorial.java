package exam;

public class factorial {
	

		
		public static long facto(int n){
			if(n==0||n==1) {
				return 1;
			}
			else {
				return n*facto(n-1);
			}
		}
		public static double combi(int n,int r) {
			if(n<r) {
				return 0;
			}
			else {
				long numerator=facto(n);
				long deno=facto(r)*facto(n-r);
				return numerator/deno;
			}
		}
		
	}




