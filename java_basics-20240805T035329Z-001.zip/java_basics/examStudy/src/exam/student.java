package exam;

class student extends mthdovr{
	private int rollno;
	public student(String name,int age,int rollno) {
		
	}
	
}