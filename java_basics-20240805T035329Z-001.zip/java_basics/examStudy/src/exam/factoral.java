package exam;
import java.io.*;
public class factoral {

	public static void main(String[] args) {
		DataInputStream dis=new DataInputStream(System.in);
		try {
			System.out.println("enter the number");
			String s=dis.readLine();
			int n=Integer.parseInt(s);
			System.out.println("factorial="+factorial(n));
			System.out.println("Descendingorder");
			descending(n);
			System.out.println("AScendingorder:");
			ascending(n);
            
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
    static int factorial(int n) {
    	if(n==0||n==1) {
    		return 1;
    	}
    	else {
    		
    		return n*factorial(n-1);
    	}
    	
    }
    static void descending(int n) {
        if(n>=1) {
        	System.out.println(n+" ");
        	 descending(n-1);
        }
		
    }
    static void ascending(int n) {
        if(n>=1) {
        	 ascending(n-1);
        	System.out.println(n+" ");
        	
        }
		
    }

}
