package exam;
import java.io.*;
import java.lang.*;
public class sum {
	public static void main(String[] args) {
		DataInputStream dis=new DataInputStream(System.in);
		try {
			int a,b,c;
			String s,f;
			System.out.println("enter a no.:");
			s=dis.readLine();
			a=Integer.parseInt(s);
			System.out.println("enter 2nd no.:");
			s=dis.readLine();
			b=Integer.parseInt(s);
			System.out.println("enter 3rd no.:");
			s=dis.readLine();
			c=Integer.parseInt(s);
			int max,mn;
//			if(a>=b && a>=c) {
//				System.out.println("max is:"+a);
//			}
//			else if(b>=a && b>=c) {
//				System.out.println("max is:"+b);
//			}
//			else if(c>=a && c>=b) {
//				System.out.println("max is:"+c);
//			}
//			if(a<=b && a<=c) {
//				System.out.println("min is:"+a);
//			}
//			else if(b<=a && b<=c) {
//				System.out.println("min is:"+b);
//			}
//			else if(c<=a && c<=b) {
//				System.out.println("min is:"+c);
//			}
			mn=Math.min(Math.min(a, b),c);
			System.out.println("min="+mn);
//			System.out.println("before swap a="+a+"and b="+b);
//			int  t=a;
//			a=b;
//			b=t;
//			System.out.println("swap a="+a+" and b="+b);
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}

}
