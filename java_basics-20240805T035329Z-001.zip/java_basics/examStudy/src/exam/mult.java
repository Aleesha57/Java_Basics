package exam;
import java.io.*;
public class mult {
	public static void main(String[] args) {
		String s;
		DataInputStream dis=new DataInputStream(System.in);
		try {
			System.out.println("enter the first no:");
			s=dis.readLine();
			int a=Integer.parseInt(s);
			System.out.println("enter the 2nd no:");
			s=dis.readLine();
			int b=Integer.parseInt(s);
			System.out.println(a+"*"+b+"="+a*b);
		}catch(Exception e) {
			System.out.println(e);
		}
	}

	
}
