package exam;
import java.io.*;
public class paliamdrome {
	public static void main(String[] args) {
		DataInputStream dis=new DataInputStream(System.in);
		String s;
		int num;
		try {
			System.out.println("enter the number");
			s=dis.readLine();
			num=Integer.parseInt(s);
			System.out.println("number ="+num);
			if(Ispaliamdrome(num)) {
				System.out.println("the number is palimdrome");
			}
			else {
				System.out.println("the number is not palimdrome");
			}
			
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	public static int reverseInteger(int num) {
		int reverse =0;
		while(num!=0) {
			
			int digit=num % 10;
			reverse=reverse*10+digit;
			num/=10;
		}
	return reverse;	
	}
	public static boolean Ispaliamdrome(int num) {
		return num==reverseInteger(num);
		
		
	}

}
