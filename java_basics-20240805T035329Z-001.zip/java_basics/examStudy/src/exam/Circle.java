package exam;
import java.io.*;
interface Shape{
	void disp();
	void calc();
}
class Circle implements Shape{
	int r;
	double pi=3.14;
	public  Circle(int r){
		this.r=r;
		this.pi=pi;
	}
	public void disp() {
		System.out.println("displaying the circle");
	}
	public void calc() {
		double area=pi*r*r;
		System.out.println("area of the circle:"+area);
	}
	

}
