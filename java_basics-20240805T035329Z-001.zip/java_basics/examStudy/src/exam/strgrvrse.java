package exam;
import java.io.*;
public class strgrvrse {
	public static String reverse(String input) {
		char[] chararray=input.toCharArray();
		int start=0;
		int end=chararray.length-1;
		while(start<end) {
			char temp=chararray[start];
			chararray[start]=chararray[end];
			chararray[end]=temp;
			start++;
			end--;
		}
		return new String(chararray);
		
	}
	public static void main(String[] args) {
		DataInputStream dis=new DataInputStream(System.in);
		try {
			System.out.println("enter the string:");
			String s=dis.readLine();
			String reversed=reverse(s); 
			System.out.println("before reversd String :"+s);
			System.out.println("reversd String :"+reversed);
		}catch(Exception e) {
			System.out.println(e);
		}
	}

}
