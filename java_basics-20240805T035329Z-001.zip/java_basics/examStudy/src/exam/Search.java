package exam;
import java.io.*;
public class Search {
	public static void main(String[] args) {
		DataInputStream dis=new DataInputStream(System.in);
		String s;
		int a[];
		int n,i,j;
		try {
			System.out.println("enter the size of the array:");
			s=dis.readLine();
			n=Integer.parseInt(s);
			a=new int[n];
			System.out.println("enter the elements in array");
			for(i=0;i<n;i++) {
				s=dis.readLine();
				a[i]=Integer.parseInt(s);
			}
			System.out.println(" elements in array:");
			for(i=0;i<n;i++) {
				System.out.println(a[i]);
			}
			BSort( a);
			System.out.println(" after sorting elements in array:");
			for(i=0;i<n;i++) {
				System.out.println(a[i]);
			}
			
//			System.out.println(" enter the element to search");
//			s=dis.readLine();
//			int k=Integer.parseInt(s);
//			int flag=0;
//			for(i=0;i<n;i++) {
//				if(a[i]==k)
//				{
//					
//					System.out.println("element found at"+i+"="+a[i]);
//					flag=1;
//					break;
//				}
//				
//			}
//			if(flag==0)
//			{
//				
//				System.out.println("element not found");
//				
//			}
			
			
		}catch(Exception e) {
			System.out.println(e);
		}
		
}
	static void BSort(int[] a) {
		int n,i,j;
		 n=a.length;
		for(i=0;i<n;i++) {
			for(j=0;j<n-i-1;j++) {
				if(a[j]>a[j+1]) {
					int temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
				
			}
		}
	}
}

